import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Calendar } from "@/components/ui/calendar";

export default function Home() {
  const [date, setDate] = useState(null);
  return (
    <div className="max-w-3xl mx-auto p-6 space-y-8">
      <section className="text-center space-y-4">
        <div className="rounded-xl overflow-hidden">
          <img
            src="/images/hero-lawn.jpg"
            alt="Pelouse bien tondue"
            className="w-full h-auto"
          />
        </div>
        <h1 className="text-4xl font-bold">DC Compagnie de Gazon</h1>
        <p className="mt-2 text-lg">Par Donavan Cayer – Fiable, sérieux, et prêt à vous satisfaire.</p>
      </section>

      <section>
        <Card>
          <CardContent className="p-6 space-y-4">
            <h2 className="text-2xl font-semibold">Nos services</h2>
            <ul className="list-disc list-inside text-lg">
              <li>Tonte de gazon — Prix selon la taille du terrain</li>
            </ul>
            <div className="rounded-xl overflow-hidden">
              <img
                src="/images/lawn-service.jpg"
                alt="Tonte de pelouse"
                className="w-full h-auto"
              />
            </div>
          </CardContent>
        </Card>
      </section>

      <section>
        <Card>
          <CardContent className="p-6 space-y-4">
            <h2 className="text-2xl font-semibold">Contact & Réservation</h2>
            <p>Pour réserver un créneau ou poser une question, utilisez le formulaire ci-dessous.</p>
            <form className="space-y-4">
              <Input type="text" placeholder="Votre nom" required />
              <Input type="email" placeholder="Votre email" required />
              <Textarea placeholder="Votre message ou adresse" required />
              <div>
                <p className="mb-2">Choisissez une date :</p>
                <Calendar mode="single" selected={date} onSelect={setDate} className="rounded-md border" />
              </div>
              <Button type="submit">Envoyer la demande</Button>
            </form>
            <p className="text-sm text-gray-500">Ou contactez-moi directement : donavancayer87@gmail.com</p>
            <div className="rounded-xl overflow-hidden">
              <img
                src="/images/mowing-person.jpg"
                alt="Personne tondant la pelouse"
                className="w-full h-auto"
              />
            </div>
          </CardContent>
        </Card>
      </section>
    </div>
  );
}
